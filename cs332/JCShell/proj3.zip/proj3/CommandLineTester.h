/*
 * CommandLineTester.h
 *
 *  Created on: Mar 12, 2014
 *      Author: jgl5
 */

#ifndef COMMANDLINETESTER_H_
#define COMMANDLINETESTER_H_

class CommandLineTester {
public:
	CommandLineTester();
	void run();

};

#endif /* COMMANDLINETESTER_H_ */
